package App::freq ;  
our $VERSION = '0.100' ; 
our $DATE = '2021-06-07T00:52+09:00' ; 

=encoding utf8

=head1 NAME

App::freq

=head1 SYNOPSIS

This module provides a Unix-like command `F<freq>'. 
The function is similar to `sort | uniq -c' also with many useful functions.

=head1 DESCRIPTION



=head1 SEE ALSO


=cut

1 ;
